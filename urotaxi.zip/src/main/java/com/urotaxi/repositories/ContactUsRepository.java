package com.urotaxi.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.urotaxi.entities.ContactUs;

public interface ContactUsRepository extends JpaRepository<ContactUs, Integer> {

}
