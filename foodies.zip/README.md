# foodies
foodies application with dynamic content demonstration
